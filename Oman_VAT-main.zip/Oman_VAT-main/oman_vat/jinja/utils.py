import json

def string_to_json(json_string):
    return json.loads(json_string)