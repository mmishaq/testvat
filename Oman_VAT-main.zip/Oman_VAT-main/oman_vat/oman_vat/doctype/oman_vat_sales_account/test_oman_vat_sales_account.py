# Copyright (c) 2022, ERPGulf and Contributors
# See license.txt

# import frappe
import unittest

class TestOMANVATSalesAccount(unittest.TestCase):
	pass
