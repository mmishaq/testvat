frappe.listview_settings['OMAN VAT Setting'] = {
    onload(list) {
        frappe.breadcrumbs.add('Accounts');
    }
}