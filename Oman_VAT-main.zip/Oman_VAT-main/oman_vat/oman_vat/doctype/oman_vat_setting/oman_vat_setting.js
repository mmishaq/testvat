// Copyright (c) 2022, ERPGulf and contributors
// For license information, please see license.txt

frappe.ui.form.on('OMAN VAT Setting', {
	onload: function(frm) {
		frappe.breadcrumbs.add('Accounts', 'OMAN VAT Setting');
	}
});
